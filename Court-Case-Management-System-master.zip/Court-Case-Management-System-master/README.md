# Court-Case-Management-System
ABSTRACT

We all wonder to see the future corruption free and developed Utopia like Ethiopia, But have you ever wonder what if the non-transparent and poor file handling system in legal system is slowing us down or what if the court system is also facilitating the accelerated growth of corruption in our country. Most of us might be asking ourselves why we are using paper for registering, witness records, appealing process and other manual works while living in the twenty first century.

In this project we have presented a new and reliable system that aims to facilitate and provide a way to solve this huge problem domain, by giving the best result that can combine the current technologies, the social integrity and also the court legal and work system by using the internet and soft-wares. Other than this the system can also provide the digitization of documents, easy data backup, easy data access and manipulation. 

In today’s global economy courts are no longer immune to competition. Modern justice systems must remain efficient, cost effective and pioneering to stay competitive. Implementing new technology will help the judiciary meet the evolving needs of judges and the business community. Our Platform eliminates outdated processes that hinder justice and accelerates the judicial process.
About The system
First the user has to perform a login activity. Once the system authentication is done the user will be either authorized to access the system that fits his privilege (Administrator, Judge, Plaintiff or Accused) or denied by the system.

If the user is Administrator he/she will be able to add new Judges, new cases with their plaintiff and accused information, able to post new notifications for other users, update waiting list cases if there are free judges available, view the court over all activity as organized report and finally can change password.

If the user is a Judge he/she will be able to view their notifications if there is, to update cases information (Extend the court date by providing appointments or may close the case by providing a final decision document), able to add witness document to a case, view their work progress report and finally can change password like others.

If the user is plaintiff or accused he/she will be able to view their cases progress and status, to appeal on a case if it is closed and they think the decision is not satisfactory, able to view their own notifications if any and finally can change their password.

Feature List

The process of court case management involves the following actions

    • Creating or registering a case
    • Registering a judge to a case 
    • Notifying the judge about their cases 
    •  Notifying accused and plaintiff about the progress of the case
    • Generating a report about cases in the court have
    • Plaintiff and accused can appeal on their case’s judge decission 

Features:
1. Case
2. Notification
3. Appeal 
4. Statistic & Report
5. Search
