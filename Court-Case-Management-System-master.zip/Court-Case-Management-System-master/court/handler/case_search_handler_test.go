package handler

// import (
// 	"net/http"
// 	"net/http/httptest"
// 	"testing"
// )

// func TestAdminCases(t *testing.T) {
// 	httprr := httptest.NewRecorder()
// 	req, err := http.NewRequest("GET", "/v1/admin/cases", nil)
// 	if err != nil {
// 		t.Fatal(err)
// 	}

// 	Cases(httprr, req)
// 	resp := httprr.Result()

// }
